package main.Model.Products;



//import org.json.simple.JSONObject;
//import org.json.simple.JSONArray;
//import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.List;

public class LoadProducts {
    /*
    public static List<? extends Product> load() {
        List<? extends Product> allProducts;
        JSONParser jsnoParser = new JSONParser();
        try (FileReader reader = new FileReader("files/Products/items.json"));
    }
    public static void write(List<? extends Product> lst) {
        for (Product item : lst) {
            if (item instanceof Fruits)
        }
    }*/
}
//to delete